from pathlib import Path

root=Path(__file__).resolve().parents[1]
docs=root/'docs/gd2'
for name in ['KE_HOACH_GD2.md','PHAC_THAO_BAO_CAO_GD2.md','DOI_CHIEU_CAC_TAP_TAC_PHAM.md']:
    p=docs/name
    s=p.read_text(encoding='utf-8')
    # Update active guidance; historical JSON and submitted GD1 files stay untouched.
    replacements={
      'docs/GD1-CSDLDPT-23-03.pdf':'docs/gd1/GD1-CSDLDPT-23-03.pdf',
      'docs/GD2_planning_audit.json':'docs/audit/GD2_planning_audit.json',
      'docs/GD2_metadata_audit.json':'docs/audit/GD2_metadata_audit.json',
      'docs/GD2_volume_verification.json':'docs/audit/GD2_volume_verification.json',
      'docs/DOI_CHIEU_CAC_TAP_TAC_PHAM.md':'docs/gd2/DOI_CHIEU_CAC_TAP_TAC_PHAM.md',
      'docs/PHAC_THAO_BAO_CAO_GD2.md':'docs/gd2/PHAC_THAO_BAO_CAO_GD2.md',
      'gd1_out/':'gd1/results/',
      'label_content_audit/':'data/provenance/',
      '`gd1_out`':'`gd1/results`',
      '`gd1_stats.py`':'`gd1/gd1_stats.py`',
      '`labels.jsonl`':'`data/metadata/labels.jsonl`',
      '`selected_stories.csv`':'`data/metadata/selected_stories.csv`',
      'mới kiểm tra, chưa sửa hai title này':'đã bổ sung tên tập trong CSV',
      'rà hai nhóm trùng tên–tác giả và nguồn tác phẩm':'đã xác minh tập/phần của hai nhóm cùng tác phẩm',
      'Số 998 cặp tên–tác giả phân biệt chưa phải số tác phẩm đã xác minh.':'Số cặp tên–tác giả trong bảng không phải phép đếm tác phẩm đã xác minh.',
      'chốt các vấn đề nguồn/metadata':'sử dụng metadata đã chốt và bổ sung nguồn truy vấn',
    }
    for old,new in replacements.items():
        s=s.replace(old,new)
    if name=='KE_HOACH_GD2.md':
        s=s.replace('Cập nhật: 04/11/2026 sau khi tìm lại `data/metadata/selected_stories.csv`.',
                    'Cập nhật: 04/11/2026 sau khi chốt bốn tên tập/phần, lưu mốc và sắp xếp thư mục.')
        s=s.replace('Tạo nhánh thư mục mới, không chuyển 1.000 TXT nếu việc chuyển không cần thiết:',
                    'Bố cục dưới đây đã được sắp xếp trước GD2. Tệp TXT giữ nguyên filename và nội dung, chỉ chuyển vào data/corpus; thư mục gd2/ là phần dự kiến tạo khi triển khai:')
        start=s.index('```text\nCSDLDPT/')
        end=s.index('```',start+3)+3
        s=s[:start]+'''```text
CSDLDPT/
  data/corpus/                        # 1.000 TXT GD1, nguyên byte
  data/metadata/                      # selected_stories.csv, labels.jsonl
  data/provenance/                     # nhật ký rà soát nhãn
  gd1/gd1_stats.py                     # mã GD1 nguyên gốc
  gd1/results/                        # kết quả GD1 nguyên gốc
  docs/gd1/                           # PDF GD1 đã nộp
  docs/gd2/                           # kế hoạch, phác thảo, làm rõ GD1
  docs/audit/                         # bằng chứng kiểm tra và đổi đường dẫn
  baselines/pre_gd2_2026-11-04/         # manifest, cấu hình, stopword, snapshot
  tools/verify_baseline.py             # kiểm tra mốc chỉ đọc
  archive/                            # lịch sử tệp tạm đã nén
  gd2/                                # dự kiến khi bắt đầu GD2
    src/, config/, database/
    queries/, sources/, results/, evaluation/, report/
```'''+s[end:]
        s=s.replace('Chỉ mẫu `book_*.txt` của thư mục kho được tham gia fit.',
                    'Chỉ mẫu `data/corpus/book_*.txt` được tham gia fit.')
        s=s.replace('| P0 Chốt hiện trạng | Lập manifest/hash, lưu cấu hình, giữ nguyên GD1 | Checklist kế thừa, manifest | Đủ 1.000 tệp, số liệu khớp | 0,5 buổi |',
                    '| P0 Chốt hiện trạng | Đã lưu manifest/hash, cấu hình, stopword và snapshot GD1 | baselines/pre_gd2_2026-11-04 | Hoàn thành; đủ 1.000 tệp, số liệu khớp, có script kiểm tra | Đã xong |')
        s=s.replace('Bước tiếp theo hợp lý khi bắt đầu triển khai là P0–P1, rồi tái lập đúng TF-IDF trước khi xây CSDL và chạy đánh giá.',
                    'P0 và phần kiểm tra metadata của P1 đã hoàn thành. Bước tiếp theo là P2: tái lập đúng TF-IDF trước khi xây CSDL và chạy đánh giá; bổ sung nguồn truy vấn theo P5.')
        s=s.replace('Nêu kết quả đối chiếu nếu hai nhóm trùng tên làm thay đổi mô tả tính đầy đủ của tác phẩm; nêu làm rõ BOM/nguồn stopword.',
                    'Dùng nội dung đã chốt trong `docs/gd2/LAM_RO_GD1_TRUOC_GD2.md` để làm rõ đơn vị tệp/tập tác phẩm, BOM và nguồn stopword.')
        s=s.replace('- [ ] Bộ 1.000 tệp, nhãn và số liệu GD1 giữ nguyên; có manifest/hash.',
                    '- [x] Bộ 1.000 tệp, nhãn và số liệu GD1 giữ nguyên; có manifest/hash và kiểm tra trước/sau chuyển thư mục.')
        s=s.replace('- [ ] Các câu chưa chính xác của GD1 được làm rõ công khai; không đổi thuật toán để khớp lỗi diễn đạt.',
                    '- [x] Đã chốt văn bản làm rõ GD1; đưa vào PDF hợp nhất khi soạn báo cáo, giữ nguyên thuật toán.')
    elif name=='PHAC_THAO_BAO_CAO_GD2.md':
        s=s.replace('Cập nhật: 04/11/2026 sau khi tìm lại `data/metadata/selected_stories.csv`.',
                    'Cập nhật: 04/11/2026 sau khi hoàn tất chuẩn bị, chốt metadata và sắp xếp thư mục.')
        s=s.replace('### B.3 Ghi chú làm rõ cần xử lý',
                    '### B.3 Ghi chú làm rõ đã chốt để đưa vào bản hợp nhất\n\nDùng các đoạn đã soạn trong [LAM_RO_GD1_TRUOC_GD2.md](LAM_RO_GD1_TRUOC_GD2.md); chưa sửa PDF GD1 đã nộp.')
        s=s.replace('giữ đúng GD1, sử dụng bảng tác phẩm–tác giả đã tìm lại và kiểm chứng các điểm nghi vấn,',
                    'giữ đúng GD1, sử dụng metadata và phần làm rõ đã chốt,')
    else:
        s=s.replace('Chỉ hai ô title ở dòng CSV 638 và 798 đã được sửa theo yêu cầu.',
                    'Hai ô title Grania ở dòng CSV 638 và 798 đã được sửa; hai ô The Earl’s Promise ở dòng 928 và 989 cũng đã được bổ sung tên tập trong bước chốt chuẩn bị.')
        s=s.replace('Tên hiển thị đề xuất cho hai tệp (chưa sửa vào CSV vì yêu cầu hiện tại là kiểm tra):',
                    'Tên hiển thị đã cập nhật trong CSV ở bước chốt chuẩn bị:')
        s=s.replace('Bằng chứng chi tiết: `GD2_volume_verification.json`; nhật ký hai ô CSV đã sửa: `GD2_metadata_title_changes.json`.',
                    'Bằng chứng chi tiết: `docs/audit/GD2_volume_verification.json`; nhật ký bốn ô CSV đã sửa: `docs/audit/GD2_metadata_title_changes.json`.')
    p.write_text(s,encoding='utf-8')
print('Updated current planning documents and paths.')
