import csv, hashlib, json, re
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parents[2]
files = sorted(root.glob('book_*.txt'))
old = {r['filename']: r for r in csv.DictReader((root/'gd1_out/doc_stats.csv').open(encoding='utf-8-sig'))}
rx = re.compile(r"[a-z]+(?:'[a-z]+)?")
counts, mismatches, hashes, bom = [], [], {}, 0
for p in files:
    raw = p.read_bytes()
    bom += raw.startswith(b'\xef\xbb\xbf')
    s = raw.decode('utf-8-sig')
    toks = rx.findall(s.replace('’', "'").replace('‘', "'").replace('ʼ', "'").lower())
    n = len(toks)
    counts.append(n)
    if p.name not in old or n != int(old[p.name]['n_words']):
        mismatches.append({'filename':p.name, 'current_words':n, 'previous_words':old.get(p.name, {}).get('n_words')})
    h = hashlib.sha256(' '.join(toks).encode()).hexdigest()
    hashes.setdefault(h, []).append(p.name)
labels = [json.loads(s) for s in (root/'labels.jsonl').read_text(encoding='utf-8-sig').splitlines() if s.strip()]
dist = Counter(r['primary'] for r in labels)
old_dist = {r['label']: int(r['count']) for r in csv.DictReader((root/'gd1_out/label_distribution.csv').open(encoding='utf-8-sig'))}
res = {'purpose':'Read-only input audit for GD2 planning; no TF-IDF retraining',
       'n_files':len(files), 'total_words':sum(counts), 'min_words':min(counts), 'max_words':max(counts),
       'below_12000':sum(n<12000 for n in counts), 'word_count_mismatches_with_gd1':mismatches,
       'actual_utf8_bom_files':bom, 'all_decode_utf8_sig':True,
       'normalized_duplicate_groups':[v for v in hashes.values() if len(v)>1],
       'label_rows':len(labels), 'unique_label_files':len({r['filename'] for r in labels}),
       'label_distribution_matches_gd1':dict(dist)==old_dist,
       'label_missing_files':sorted({p.name for p in files}-{r['filename'] for r in labels}),
       'label_extra_files':sorted({r['filename'] for r in labels}-{p.name for p in files}),
       'metadata_keys_in_labels':sorted({k for r in labels for k in r}),
       'pdf_sha256':hashlib.sha256((root/'docs/GD1-CSDLDPT-23-03.pdf').read_bytes()).hexdigest()}
(root/'tmp/pdfs/audit_for_plan.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(res,ensure_ascii=True,indent=2))
