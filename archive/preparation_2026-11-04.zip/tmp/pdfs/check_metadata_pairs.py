import csv
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[2]
rows = {r['new_filename']: r for r in csv.DictReader((root/'selected_stories.csv').open(encoding='utf-8-sig'))}
audit_path = root/'docs/GD2_metadata_audit.json'
audit = json.loads(audit_path.read_text(encoding='utf-8'))
rx = re.compile(r"[a-z]+(?:'[a-z]+)?")
details = []
for group in audit['duplicate_title_author_groups']:
    item = {'title':group['title'], 'documents':[]}
    tokens = []
    for name in group['files']:
        raw = (root/name).read_bytes()
        text = raw.decode('utf-8-sig')
        tok = rx.findall(text.replace('’', "'").replace('‘', "'").replace('ʼ', "'").lower())
        tokens.append(tok)
        item['documents'].append({**rows[name], 'word_count':len(tok),
            'raw_sha256':hashlib.sha256(raw).hexdigest(),
            'normalized_sha256':hashlib.sha256(' '.join(tok).encode()).hexdigest(),
            'opening':text[:800], 'ending':text[-500:]})
    item['identical_normalized_text'] = tokens[0] == tokens[1]
    item['same_first_100_tokens'] = tokens[0][:100] == tokens[1][:100]
    details.append(item)
audit['duplicate_pair_content_checks'] = details
audit['source_sha256'] = hashlib.sha256((root/'selected_stories.csv').read_bytes()).hexdigest()
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(details,ensure_ascii=False,indent=2))
