import csv, difflib, hashlib, json, re, urllib.request
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = root/'tmp/source_verification'
out.mkdir(parents=True, exist_ok=True)
rx = re.compile(r"[a-z]+(?:'[a-z]+)?")
def normalize(s):
    return ' '.join(rx.findall(s.replace('’', "'").replace('‘', "'").replace('ʼ', "'").lower()))
sources = {}
for ebook in [58443,70755,70756]:
    url = f'https://www.gutenberg.org/cache/epub/{ebook}/pg{ebook}.txt'
    path = out/f'pg{ebook}.txt'
    if not path.exists():
        with urllib.request.urlopen(url,timeout=45) as response:
            path.write_bytes(response.read())
    sources[ebook] = path.read_text(encoding='utf-8-sig')
    print('Source ready:',ebook,flush=True)
results = []
for filename,ebook,label in [('book_0637.txt',58443,'Vol. I; Parts I-II'),('book_0797.txt',58443,'Vol. II; Parts III-IV'),('book_0927.txt',70755,'Vol. 1 of 3'),('book_0988.txt',70756,'Vol. 2 of 3')]:
    raw = (root/filename).read_bytes()
    local = raw.decode('utf-8-sig')
    local_norm = normalize(local)
    source_norm = normalize(sources[ebook])
    words = local_norm.split()
    # Grania contains duplicated part captions; anchor in the first narrative paragraph.
    if ebook==58443:
        marker = 'a mild september afternoon' if filename=='book_0637.txt' else 'thus the weeks went on'
        local_start = local_norm.index(marker)
    else:
        local_start = 0
    comparable = local_norm[local_start:]
    start = source_norm.find(' '.join(comparable.split()[:60]))
    tail = ' '.join(words[-60:])
    end = source_norm.find(tail, max(start,0))
    if start<0 or end<0:
        raise RuntimeError(f'Cannot locate anchors for {filename}')
    span = source_norm[start:end+len(tail)]
    entry = {'filename':filename, 'verified_scope':label,'source_url':f'https://www.gutenberg.org/ebooks/{ebook}',
             'source_text_url':f'https://www.gutenberg.org/cache/epub/{ebook}/pg{ebook}.txt',
             'raw_sha256':hashlib.sha256(raw).hexdigest(), 'local_word_count':len(words),
             'matched_source_span_word_count':len(span.split()),
             'comparison_local_skipped_prefix_words':len(local_norm[:local_start].split()),
             'normalized_span_exact_match':comparable==span,
             'chapter_headings':re.findall(r'^\s*(CHAPTER\s+[IVXLCDM]+\.?)[ \t]*$',local,re.M),
             'part_headings':re.findall(r'^\s*(PART\s+[IVXLCDM]+)[ \t]*$',local,re.M)}
    if comparable!=span:
        sm = difflib.SequenceMatcher(None,comparable.split(),span.split(),autojunk=False)
        entry['token_alignment_ratio']=sm.ratio()
        entry['differences']=[{'operation':tag,'local_tokens':comparable.split()[i:j], 'source_tokens':span.split()[k:l]}
                              for tag,i,j,k,l in sm.get_opcodes() if tag!='equal']
    results.append(entry)
    print(json.dumps({k:v for k,v in entry.items() if k!='differences'},ensure_ascii=False),flush=True)
report={'checked_at':'2026-11-04','normalization':'GD1 word regex, lowercasing and apostrophe normalization; compare every token between matched opening and ending anchors',
        'documents':results}
(root/'docs/GD2_volume_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
