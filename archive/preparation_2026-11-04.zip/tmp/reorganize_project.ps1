$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath 'C:\Users\Tung Khanh Luong\Desktop\CSDLDPT').Path
$rootPrefix = $projectRoot.TrimEnd('\') + '\'
$plan = Get-Content -LiteralPath (Join-Path $projectRoot 'tmp\reorganization_plan.json') -Raw | ConvertFrom-Json
$checkedMoves = foreach ($entry in $plan.moves) {
    $sourcePath = [IO.Path]::GetFullPath((Join-Path $projectRoot $entry.from))
    $targetPath = [IO.Path]::GetFullPath((Join-Path $projectRoot $entry.to))
    if (-not $sourcePath.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase) -or -not $targetPath.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path leaves project workspace' }
    $sourceItem = Get-Item -LiteralPath $sourcePath
    if ($sourceItem.PSIsContainer -or ($sourceItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Expected ordinary file: $sourcePath" }
    if (Test-Path -LiteralPath $targetPath) { throw "Target already exists: $targetPath" }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $sourcePath).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Source changed: $sourcePath" }
    [PSCustomObject]@{ Source=$sourcePath; Target=$targetPath; ExpectedHash=$entry.sha256; OldPath=$entry.from; NewPath=$entry.to }
}
if (($checkedMoves.Target | Select-Object -Unique).Count -ne $checkedMoves.Count) { throw 'Duplicate destination' }
foreach ($entry in $checkedMoves) {
    $targetParent = Split-Path -Parent $entry.Target
    if (-not (Test-Path -LiteralPath $targetParent)) { New-Item -ItemType Directory -Path $targetParent | Out-Null }
    Move-Item -LiteralPath $entry.Source -Destination $entry.Target
}
$verified = 0
foreach ($entry in $checkedMoves) {
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $entry.Target).Hash.ToLowerInvariant() -ne $entry.ExpectedHash) { throw "Hash changed after move: $($entry.Target)" }
    $verified++
}
foreach ($name in @('gd1_out','label_content_audit')) {
    $emptyDirectory = [IO.Path]::GetFullPath((Join-Path $projectRoot $name))
    if (-not $emptyDirectory.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid cleanup directory' }
    if ((Get-ChildItem -LiteralPath $emptyDirectory -Force | Measure-Object).Count -eq 0) { Remove-Item -LiteralPath $emptyDirectory }
}
$report = [ordered]@{ date='2026-11-04'; moved_files=$verified; all_moved_file_hashes_unchanged=$true; moves=@($checkedMoves | Select-Object OldPath,NewPath,ExpectedHash) }
$report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $projectRoot 'docs\audit\project_reorganization.json') -Encoding utf8
Write-Output "Moved and verified $verified files without content changes."
