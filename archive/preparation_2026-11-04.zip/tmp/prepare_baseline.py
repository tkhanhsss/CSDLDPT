"""Capture the agreed pre-GD2 state; plan file moves without changing sources."""
import csv
import hashlib
import importlib.util
import json
import platform
import shutil
import sys
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parents[1]
baseline = root/'baselines/pre_gd2_2026-11-04'
if baseline.exists():
    raise SystemExit('Baseline already exists; refusing to overwrite it.')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

spec = importlib.util.spec_from_file_location('gd1_reference', root/'gd1_stats.py')
gd1 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gd1)
summary = json.loads((root/'gd1_out/summary.json').read_text(encoding='utf-8'))
stats = {r['filename']:r for r in csv.DictReader((root/'gd1_out/doc_stats.csv').open(encoding='utf-8-sig'))}
labels = [json.loads(line) for line in (root/'labels.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
metadata = list(csv.DictReader((root/'selected_stories.csv').open(encoding='utf-8-sig',newline='')))
files = sorted(root.glob('book_*.txt'))
expected = {f'book_{i:04d}.txt' for i in range(1,1001)}
assert {p.name for p in files} == expected
assert len(metadata)==1000 and {r['new_filename'] for r in metadata}==expected
assert len(labels)==1000 and {r['filename'] for r in labels}==expected
assert all(all(r[k].strip() for k in ['new_filename','original_filename','title','author']) for r in metadata)
changes = json.loads((root/'docs/GD2_metadata_title_changes.json').read_text(encoding='utf-8'))['changes']
original_rows = list(csv.DictReader((root/'tmp/metadata_edit/selected_stories.before-title-edit.csv').open(encoding='utf-8-sig')))
assert len(changes)==4
diffs = [(a['new_filename'],k) for a,b in zip(original_rows,metadata) for k in a if a[k]!=b[k]]
assert diffs==[(f'book_{n:04d}.txt','title') for n in [637,797,927,988]]

corpus=[]
bom_count=0
for path in files:
    raw=path.read_bytes()
    text=raw.decode('utf-8-sig')
    tokens=gd1.WORD_RE.findall(gd1.normalize_text(text).lower())
    assert len(tokens)==int(stats[path.name]['n_words']), path.name
    bom_count += raw.startswith(b'\xef\xbb\xbf')
    corpus.append({'filename':path.name,'path':f'data/corpus/{path.name}',
                   'size_bytes':len(raw),'sha256':digest(raw),
                   'normalized_token_sha256':digest(' '.join(tokens).encode('utf-8')),
                   'word_count':len(tokens)})
assert sum(r['word_count'] for r in corpus)==34344608
assert min(r['word_count'] for r in corpus)==12072
assert max(r['word_count'] for r in corpus)==53913

moves=[{'from':r['filename'],'to':r['path'],'sha256':r['sha256']} for r in corpus]
asset_pairs=[('selected_stories.csv','data/metadata/selected_stories.csv'),
             ('labels.jsonl','data/metadata/labels.jsonl'),
             ('gd1_stats.py','gd1/gd1_stats.py')]
asset_pairs += [(p.relative_to(root).as_posix(),f'gd1/results/{p.name}') for p in sorted((root/'gd1_out').iterdir()) if p.is_file()]
asset_pairs += [(p.relative_to(root).as_posix(),f'data/provenance/{p.name}') for p in sorted((root/'label_content_audit').iterdir()) if p.is_file()]
asset_pairs += [('docs/GD1-CSDLDPT-23-03.pdf','docs/gd1/GD1-CSDLDPT-23-03.pdf')]
assets=[]
for old,new in asset_pairs:
    raw=(root/old).read_bytes()
    entry={'path':new,'original_path':old,'size_bytes':len(raw),'sha256':digest(raw),
           'snapshot_path':f'snapshots/{new}'}
    assets.append(entry)
    moves.append({'from':old,'to':new,'sha256':entry['sha256']})
for p in sorted((root/'docs').iterdir()):
    if not p.is_file() or p.suffix=='.pdf':
        continue
    target=f'docs/{"audit" if p.suffix==".json" else "gd2"}/{p.name}'
    moves.append({'from':p.relative_to(root).as_posix(),'to':target,'sha256':digest(p.read_bytes())})

versions={'python':platform.python_version(),'numpy':gd1.np.__version__,'pandas':gd1.pd.__version__,
          'matplotlib':gd1.matplotlib.__version__,'scikit_learn':gd1.sklearn.__version__,
          'scipy':gd1.scipy.__version__,'nltk':gd1.nltk.__version__}
version_matches={k:v==summary['run_metadata'][k+'_version'] for k,v in versions.items()}
assert all(version_matches.values()),version_matches
tfidf=gd1.TfidfVectorizer(tokenizer=gd1.content_tokens,token_pattern=None,lowercase=False,
                        min_df=3,max_df=0.6,sublinear_tf=True,use_idf=True,smooth_idf=True,norm='l2')
params=tfidf.get_params()
params['tokenizer']='gd1_stats.content_tokens'
params['dtype']='float64'
config={'baseline_id':'pre_gd2_2026-11-04','date':'2026-11-04','timezone':'Asia/Bangkok',
        'corpus':{'directory':'data/corpus','pattern':'book_*.txt','n_files':1000,'row_order':'filename ascending',
                  'min_words':12000,'word_count_regex':gd1.WORD_RE.pattern,'words_per_page_assumption':600},
        'preprocessing':{'apostrophe_replacements':{'’':"'",'‘':"'",'ʼ':"'"},'lowercase':True,
                         'token_base':"token.split(\"'\")[0]",'min_base_length':2,
                         'filter_before_stemming':True,'stemmer':'nltk.stem.PorterStemmer',
                         'stemmer_mode':gd1.PORTER_STEMMER.mode,'stopword_source':'scikit-learn ENGLISH_STOP_WORDS + EXTRA_STOP'},
        'tfidf':params,'query':{'fit_on_corpus_only':True,'ranking':'cosine / dot product after L2','top_k':3,
                               'label_or_metadata_used_in_score':False},
        'reference_gd1_versions':{k:summary['run_metadata'][k+'_version'] for k in versions},
        'capture_versions':versions,'all_versions_match_gd1':all(version_matches.values()),
        'expected_feature_count_from_gd1':34416,'tfidf_rebuilt':False,
        'note':'Vocabulary, IDF and matrix were not persisted in GD1; rebuild and compare in GD2.'}
stopwords={'source':'gd1/gd1_stats.py, same scikit-learn version as GD1',
           'english_stop_words':sorted(gd1.STOP),'extra_stop':sorted(gd1.EXTRA_STOP),'stop_all':sorted(gd1.STOP_ALL)}

save(baseline/'corpus_manifest.json',{'baseline_id':config['baseline_id'],'files':corpus})
save(baseline/'asset_manifest.json',{'baseline_id':config['baseline_id'],'files':assets})
save(baseline/'configuration.json',config)
save(baseline/'stopwords.json',stopwords)
for entry in assets:
    dest=baseline/entry['snapshot_path']
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/entry['original_path'],dest)
save(baseline/'status.json',{'date':'2026-11-04','n_documents':1000,'total_words':34344608,'min_words':12072,'max_words':53913,
                          'utf8_bom_files':bom_count,'metadata_rows':len(metadata),'label_rows':len(labels),
                          'metadata_title_changes':changes,'all_word_counts_match_gd1':True,
                          'versions_match_gd1':version_matches,'tfidf_rebuilt':False})
save(root/'tmp/reorganization_plan.json',{'root':str(root),'moves':moves})
save(root/'tmp/capture_result.json',{'baseline':str(baseline),'corpus_files':len(corpus),'assets':len(assets),
                                  'moves':len(moves),'all_versions_match_gd1':True})
print((root/'tmp/capture_result.json').read_text(encoding='utf-8'))
