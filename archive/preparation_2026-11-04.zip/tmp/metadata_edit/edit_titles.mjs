import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook } from '@oai/artifact-tool';

const root = 'C:/Users/Tung Khanh Luong/Desktop/CSDLDPT';
const dir = path.join(root, 'tmp/metadata_edit');
const input = path.join(root, 'selected_stories.csv');
const original = await fs.readFile(input, 'utf8');
const wb = await Workbook.fromCSV(original, {sheetName:'Metadata'});
const sheet = wb.worksheets.getItemAt(0);
const before = sheet.getRange('A1:D1001').values;
const edits = new Map([
  ['book_0927.txt',"The Earl's Promise (Vol. 1 of 3)"],
  ['book_0988.txt',"The Earl's Promise (Vol. 2 of 3)"],
]);
// CSV has no persisted presentation; widths apply only to inspection PNGs.
sheet.getRange('A1:B1001').format.columnWidthPx = 140;
sheet.getRange('C1:C1001').format.columnWidthPx = 480;
sheet.getRange('D1:D1001').format.columnWidthPx = 170;
sheet.getRange('A1:D1001').format.font = {name:'Arial',size:11};
for (const filename of edits.keys()) {
  const idx = before.findIndex(r=>r[0]===filename);
  if(idx<1) throw Error(`Missing ${filename}`);
  if(process.argv[2]==='edit') sheet.getCell(idx,2).values = [[edits.get(filename)]];
}
wb.recalculate();
for (const filename of edits.keys()) {
  const idx = before.findIndex(r=>r[0]===filename);
  const preview = await wb.render({sheetName:'Metadata',range:`A${idx+1}:D${idx+1}`,scale:1,format:'png'});
  await fs.writeFile(path.join(dir,`${filename}.${process.argv[2]}.png`),new Uint8Array(await preview.arrayBuffer()));
}
if(process.argv[2]==='edit') {
  const after = sheet.getRange('A1:D1001').values;
  const changes=[];
  for(let i=0;i<before.length;i++) for(let j=0;j<4;j++) {
    if(before[i][j]!==after[i][j]) changes.push({row:i+1,column:j+1,filename:before[i][0],before:before[i][j],after:after[i][j]});
  }
  if(changes.length!==2 || changes.some(x=>x.column!==3 || !edits.has(x.filename))) throw Error('Unexpected scope');
  // Preserve the original CSV byte layout outside the two title fields.
  // Values authored and checked through Artifact Tool above are the replacement source.
  let updated=original;
  for(const change of changes) {
    const idx=change.row-1;
    const encode = value => /[,"\r\n]/.test(value) ? '"'+String(value).replaceAll('"','""')+'"' : String(value);
    const oldField=encode(change.before);
    const newField=encode(after[idx][2]);
    const oldRow=before[idx][0]+','+before[idx][1]+','+oldField+','+before[idx][3];
    const newRow=after[idx][0]+','+after[idx][1]+','+newField+','+after[idx][3];
    if(updated.split(oldRow).length!==2) throw Error('Source row is not unique');
    updated=updated.replace(oldRow,newRow);
  }
  await fs.writeFile(path.join(dir,'selected_stories.before-earl-title-edit.csv'),original);
  await fs.writeFile(input,updated);
  const logPath=path.join(root,'docs/GD2_metadata_title_changes.json');
  const log=JSON.parse(await fs.readFile(logPath,'utf8'));
  log.changes.push(...changes);
  await fs.writeFile(logPath,JSON.stringify(log,null,2));
  console.log(JSON.stringify(changes));
} else console.log('Prepared source previews; no CSV edits.');
