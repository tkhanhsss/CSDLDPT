import hashlib
import json
import os
import stat
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
baseline=root/'baselines/pre_gd2_2026-11-04'
def sha256(data):
    return hashlib.sha256(data).hexdigest()
def save(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

integrity_path=baseline/'integrity.json'
if integrity_path.exists():
    raise SystemExit('Baseline already sealed; refusing to rewrite integrity.')
entries=[{'path':p.relative_to(baseline).as_posix(),'sha256':sha256(p.read_bytes())}
         for p in sorted(baseline.rglob('*')) if p.is_file()]
save(integrity_path,{'baseline_id':'pre_gd2_2026-11-04','files':entries})

tmp=root/'tmp'
archive=root/'archive/preparation_2026-11-04.zip'
if archive.exists():
    raise SystemExit('Archive already exists; refusing to overwrite.')
files=[]
skipped=[]
for parent,dirs,names in os.walk(tmp,followlinks=False):
    for dirname in dirs[:]:
        p=Path(parent)/dirname
        if p.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            skipped.append(p.relative_to(root).as_posix())
            dirs.remove(dirname)
    for name in names:
        p=Path(parent)/name
        if p.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise RuntimeError(f'Unexpected file link: {p}')
        files.append(p)
manifest=[{'path':p.relative_to(root).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha256(p.read_bytes())} for p in sorted(files)]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for entry in manifest:
        z.write(root/entry['path'],entry['path'])
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={x['path'] for x in manifest}
    for entry in manifest:
        assert sha256(z.read(entry['path']))==entry['sha256'],entry['path']
report={'date':'2026-11-04','archive_path':archive.relative_to(root).as_posix(),
        'archive_sha256':sha256(archive.read_bytes()),'archive_size_bytes':archive.stat().st_size,
        'file_count':len(manifest),'skipped_reparse_points':skipped,
        'all_archived_file_hashes_verified':True,'files':manifest,'temporary_directory_removed':False}
save(root/'docs/audit/preparation_cleanup.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='files'},ensure_ascii=True,indent=2))
